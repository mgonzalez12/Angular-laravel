import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MenuComponent } from './menu.component';

@NgModule({
    imports: [ RouterModule, CommonModule, NgbModule ],
    declarations: [ MenuComponent ],
    exports: [ MenuComponent]
})

export class MenuModule {}
