import { Component, OnInit, Renderer, ViewChild, ElementRef } from '@angular/core';

import { Router } from '@angular/router';
import { Location} from '@angular/common';
import { CommonAuthService } from 'src/app/auth/common-auth.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  private listTitles: any[];
    location: Location;
    private nativeElement: Node;
    private toggleButton;
    private sidebarVisible: boolean;

    public isCollapsed = true;
    @ViewChild("app-menu", {static: false}) button;

    constructor(location:Location, private renderer : Renderer, private element : ElementRef, private router: Router, private auth: CommonAuthService) {
        this.location = location;
        this.nativeElement = element.nativeElement;
        this.sidebarVisible = false;
    }

    ngOnInit(){}

    logout(){
      let token = localStorage.getItem('token');
      this.auth.logout(token).subscribe(
        (resp) => {
          console.log("Logged Out Success");
          localStorage.clear();
          this.router.navigate(['/home/login']);
          console.log(resp);
        },
        (error) =>{
          //this.router.navigate(['/home/login'])
          console.log("Logged Out with error");
        }
      );
    }

}
