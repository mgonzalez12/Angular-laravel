import { Routes } from '@angular/router';

import { DashboardComponent } from '../../pages/dashboard/dashboard.component';
import { AuthGuardService } from '../../auth-guard.service';

export const AdminLayoutRoutes: Routes = [
    { path: 'dashboard', canActivate:[AuthGuardService],      component: DashboardComponent },
    // { path: 'user',           component: UserComponent },
    { path: 'users', canActivateChild:[AuthGuardService],
      loadChildren: () => import('../../admin/users/user.module').then(m => m.UserModule),
    }
];
