import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-layout',
  templateUrl: './welcome-layout.component.html',
  styleUrls: ['./welcome-layout.component.css']
})
export class WelcomeLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
