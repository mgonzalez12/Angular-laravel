import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserRestService } from '../user-rest.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-index',
  templateUrl: './user-index.component.html',
  styleUrls: ['./user-index.component.css']
})
export class UserIndexComponent implements OnInit {
  userList: Array<object> = [];
  polling: any;
  constructor(private route: ActivatedRoute, private userRest: UserRestService, private router: Router) { }

  ngOnInit() {
    
    this.polling = setInterval(() => {
     this.userRest.getUsers().subscribe(
     (response) => { console.log(this.userList = response.user); },
     (error) => { console.log(error) }
    );
     },3000);
  }

  deleteUser(id: number) {
    Swal.fire({
      title: 'Esta seguro ?',
      text: "No podrás revertir esto!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, elimínalo!'
    }).then((result) => {
      if (result.value) {
        this.userRest.deleteUser(id).subscribe(
          (response) => console.log(response),
         
          (error) => console.log(error)
        );
        Swal.fire(
          'Usuario Eliminado!',
          'Con éxito!',
          'success'
        )
      }
    })

  }

  editUser(id: number) {
    this.router.navigate(['users/edit',id]);
  }

  ngOnDestroy() {
    clearInterval(this.polling);
  }


}
